-- AlterTable
ALTER TABLE "Request" ADD COLUMN     "equipmentName" TEXT NOT NULL DEFAULT '';
