import { Outlet } from "react-router-dom";
import { useNavigate } from "react-router-dom"
import { useSelector } from "react-redux";
import { logout } from "../Store/auth/authSlice";
import { useDispatch } from "react-redux";
export default function AppLayout(){
      const {user} = useSelector((state:any) => state.auth.user);
      const navigate = useNavigate();
        const dispatch = useDispatch();
      const handleLogout = () => {
        dispatch(logout())
        navigate("/login")
      }
    return <div className="min-h-screen bg-background">
      <nav className="bg-card border-b border-border shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-2xl font-extrabold tracking-tight text-foreground">
                Equipment Management System
              </h1>
              <p className="text-sm text-muted-foreground">College Portal</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">{user?.name}</p>
                <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
              </div>
              <button
                onClick={handleLogout}
                className="px-4 py-2 bg-destructive text-destructive-foreground rounded-lg hover:bg-destructive/90 transition-colors text-sm font-medium"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>
        <Outlet/>
    </div>
}