"use client"

import type React from "react"

import { AdminDashboard } from "../components/AdminDashboard"
import { StudentDashboard } from "../components/StudentDashboard"
import { useSelector } from "react-redux";
export const Dashboard: React.FC = () => {

        const { user } = useSelector((state: any) => state.auth);



  return (
    

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {(user?.role).toLowerCase() === "admin" ? <AdminDashboard /> : <StudentDashboard />}
      </main>
  )
}
